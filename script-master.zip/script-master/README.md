==============================================================

MKSSHVPN AUTOSCRIPT 2017
OWNER CONTACT 
WHATSAPP : +60162771064
TELEGRAM : @mk_let

===============================================================

COMMAND TO INSTALL

----------------------------
FOR GOOGLE CLOUD SSH

wget https://raw.githubusercontent.com/zero9911/script/master/vps.sh && chmod +x vps.sh && ./vps.sh

----------------------------
FOR INSTALL SCRIPT

wget https://raw.githubusercontent.com/zero9911/script/master/install.sh && chmod +x install.sh && ./install.sh

----------------------------
FOR INSTALL SQUID3/PROXY ONLY

wget https://raw.githubusercontent.com/zero9911/script/master/proxy.sh && chmod +x proxy.sh && ./proxy.sh

-----------------------------